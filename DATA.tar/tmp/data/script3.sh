mkdir /tmp/data


echo "Hoje o dia e $(date +'%F %R')" > /tmp/data/DATA.txt


cp ./* /tmp/data


