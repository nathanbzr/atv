echo "Nada é tão ruim que não possa piorar."
